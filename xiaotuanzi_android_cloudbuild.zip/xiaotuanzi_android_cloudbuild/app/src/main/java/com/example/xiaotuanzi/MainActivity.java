package com.example.xiaotuanzi;

import android.app.Activity;
import android.graphics.*;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView mood;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setBackgroundColor(Color.rgb(255,248,238));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER); root.setPadding(24,24,24,24);
        TextView title = new TextView(this); title.setText("小团子"); title.setTextSize(28); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER); title.setTypeface(null,1);
        mood = new TextView(this); mood.setText("可我是乖蛋！"); mood.setTextSize(20); mood.setTextColor(Color.rgb(55,48,43)); mood.setGravity(Gravity.CENTER); mood.setPadding(0,16,0,18);
        PuppyView puppy = new PuppyView(this);
        puppy.setOnClickListener(v -> mood.setText("哼！不许戳脸啦……再摸摸头嘛！"));
        root.addView(title); root.addView(puppy,new LinearLayout.LayoutParams(-1,0,1)); root.addView(mood);
        Button pat = new Button(this); pat.setText("摸摸脑袋"); pat.setOnClickListener(v -> mood.setText("哼……再摸一下也不是不行！"));
        Button snack = new Button(this); snack.setText("喂小饼干"); snack.setOnClickListener(v -> mood.setText("饼干是给乖蛋的！汪！"));
        root.addView(pat); root.addView(snack); setContentView(root);
    }
    static class PuppyView extends View {
        Paint p=new Paint(3); public PuppyView(Activity c){super(c);}
        void fill(Canvas c,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);}
        void stroke(Canvas c,int color,float w){p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(w);p.setStrokeJoin(Paint.Join.ROUND);p.setStrokeCap(Paint.Cap.ROUND);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float s=Math.min(getWidth(),getHeight())/300f; c.save(); c.translate((getWidth()-300*s)/2,(getHeight()-300*s)/2);c.scale(s,s);
            int ink=Color.rgb(35,32,30), cream=Color.rgb(255,247,226), orange=Color.rgb(231,135,47);
            // ears and body silhouette
            fill(c,cream); Path body=new Path(); body.moveTo(70,105);body.lineTo(48,45);body.quadTo(45,25,65,42);body.lineTo(105,70);body.quadTo(150,48,195,70);body.lineTo(235,42);body.quadTo(255,28,250,55);body.lineTo(230,115);body.quadTo(250,185,210,220);body.lineTo(90,220);body.quadTo(48,185,70,105);body.close();c.drawPath(body,p);
            stroke(c,ink,9);c.drawPath(body,p);
            // face
            fill(c,ink); c.drawCircle(112,137,7,p);c.drawCircle(188,137,7,p); Path mouth=new Path();mouth.moveTo(142,153);mouth.lineTo(150,159);mouth.lineTo(158,153);stroke(c,ink,5);c.drawPath(mouth,p);
            // angry brows
            stroke(c,ink,7);c.drawLine(98,119,124,125,p);c.drawLine(176,125,202,119,p);
            // scarf
            fill(c,orange);Path scarf=new Path();scarf.moveTo(75,183);scarf.quadTo(150,205,225,183);scarf.lineTo(216,207);scarf.quadTo(150,228,84,207);scarf.close();c.drawPath(scarf,p);stroke(c,ink,7);c.drawPath(scarf,p);
            Path tail=new Path();tail.moveTo(185,205);tail.lineTo(205,258);tail.lineTo(225,244);tail.lineTo(218,205);tail.close();fill(c,orange);c.drawPath(tail,p);stroke(c,ink,7);c.drawPath(tail,p);
            // paws
            fill(c,cream);c.drawRoundRect(82,211,125,240,12,12,p);c.drawRoundRect(175,211,218,240,12,12,p);stroke(c,ink,7);c.drawRoundRect(82,211,125,240,12,12,p);c.drawRoundRect(175,211,218,240,12,12,p);
            c.restore(); }
    }
}
