# 小团子 Android starter

This repository builds a debug APK with GitHub Actions. After uploading these files to the repository's `main` branch, open the Actions tab, select **Build XiaoTuanzi APK**, and download the `xiaotuanzi-debug-apk` artifact from a successful run.

Note: this starter app currently contains a simple interactive puppy screen. It is not yet an always-on-top floating overlay; that requires a separate overlay service and Android permission flow.
